window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Azure Portal",
   "homepage": "https://ms.portal.azure.com/",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "kioskEnabled": false
};