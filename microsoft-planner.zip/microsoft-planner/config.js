window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Microsoft Planner",
   "homepage": "https://tasks.office.com/",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "kioskEnabled": false
};