window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Outlook Web Access",
   "homepage": "https://outlook.office.com/owa",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "kioskEnabled": false
};